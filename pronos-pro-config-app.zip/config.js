export const CONFIG = {
  API_FOOTBALL_KEY: "TA_CLE_ICI",
  APP_API_KEY: "change_me",
  PORT: 8080,
  CRON_TZ: "Europe/Paris",
  REFRESH_CRON: "*/15 * * * *"
};